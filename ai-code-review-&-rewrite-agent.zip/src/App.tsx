/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Code2, Play, RefreshCw, AlertTriangle, CheckCircle2, Info, AlertCircle, ArrowLeft } from 'lucide-react';
import { reviewCode, rewriteCode, ReviewResponse, ReviewIssue } from './services/aiService';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { motion, AnimatePresence } from 'motion/react';

const FOCUS_AREAS = ['Performance', 'Security', 'Best Practices', 'Readability', 'Bug Fixes'];

export default function App() {
  const [code, setCode] = useState('');
  const [focusAreas, setFocusAreas] = useState<string[]>([]);
  const [isReviewing, setIsReviewing] = useState(false);
  const [review, setReview] = useState<ReviewResponse | null>(null);
  const [isRewriting, setIsRewriting] = useState(false);
  const [rewrittenCode, setRewrittenCode] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleToggleFocus = (area: string) => {
    setFocusAreas(prev => 
      prev.includes(area) ? prev.filter(a => a !== area) : [...prev, area]
    );
  };

  const handleReview = async () => {
    if (!code.trim()) {
      setError('Please enter some code to review.');
      return;
    }
    setError(null);
    setIsReviewing(true);
    setReview(null);
    setRewrittenCode(null);
    try {
      const result = await reviewCode(code, focusAreas);
      setReview(result);
    } catch (err: any) {
      setError(err.message || 'An error occurred during review.');
    } finally {
      setIsReviewing(false);
    }
  };

  const handleRewrite = async () => {
    if (!code || !review) return;
    setError(null);
    setIsRewriting(true);
    try {
      const result = await rewriteCode(code, review);
      setRewrittenCode(result);
    } catch (err: any) {
      setError(err.message || 'An error occurred during rewrite.');
    } finally {
      setIsRewriting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Code2 className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-semibold tracking-tight">AI Code Review & Optimization</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column: Input */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-[600px]">
              <div className="px-4 py-3 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                <h2 className="text-sm font-medium text-slate-700">Source Code</h2>
              </div>
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Paste your code here..."
                className="flex-1 w-full p-4 font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
                spellCheck={false}
              />
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
              <h3 className="text-sm font-medium text-slate-700 mb-3">Focus Areas (Optional)</h3>
              <div className="flex flex-wrap gap-2 mb-6">
                {FOCUS_AREAS.map(area => (
                  <button
                    key={area}
                    onClick={() => handleToggleFocus(area)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                      focusAreas.includes(area)
                        ? 'bg-indigo-100 text-indigo-700 border-indigo-200'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200 border-transparent'
                    } border`}
                  >
                    {area}
                  </button>
                ))}
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleReview}
                  disabled={isReviewing || !code.trim()}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2.5 rounded-xl font-medium text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isReviewing ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Play className="w-4 h-4" />
                  )}
                  {isReviewing ? 'Analyzing...' : 'Review Code'}
                </button>
                
                {review && (
                  <button
                    onClick={handleRewrite}
                    disabled={isRewriting}
                    className="flex-1 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 px-4 py-2.5 rounded-xl font-medium text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isRewriting ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Code2 className="w-4 h-4" />
                    )}
                    {isRewriting ? 'Optimizing...' : 'Optimize Code'}
                  </button>
                )}
              </div>
              
              {error && (
                <div className="mt-4 p-3 bg-red-50 text-red-700 text-sm rounded-lg flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                  <p>{error}</p>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Output */}
          <div className="space-y-6 h-[800px] overflow-y-auto pr-2 pb-20">
            <AnimatePresence mode="wait">
              {!review && !isReviewing && !rewrittenCode && (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-200 rounded-2xl p-8 text-center"
                >
                  <Code2 className="w-12 h-12 mb-4 text-slate-300" />
                  <p className="text-sm">Paste your code and click "Review Code" to get started.</p>
                </motion.div>
              )}

              {isReviewing && (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full flex flex-col items-center justify-center text-slate-500"
                >
                  <RefreshCw className="w-8 h-8 animate-spin mb-4 text-indigo-500" />
                  <p className="text-sm font-medium">AI is analyzing and optimizing code...</p>
                  <p className="text-xs text-slate-400 mt-2">Identifying bottlenecks and best practices.</p>
                </motion.div>
              )}

              {review && !rewrittenCode && (
                <motion.div
                  key="review"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-6"
                >
                  <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
                    <h2 className="text-lg font-semibold mb-2">Summary</h2>
                    <p className="text-slate-600 text-sm leading-relaxed">{review.summary}</p>
                  </div>

                  <IssueSection title="Critical Issues" issues={review.critical} icon={<AlertTriangle className="w-5 h-5 text-red-500" />} colorClass="border-red-200 bg-red-50" headerClass="text-red-700" />
                  <IssueSection title="High Priority" issues={review.high} icon={<AlertCircle className="w-5 h-5 text-orange-500" />} colorClass="border-orange-200 bg-orange-50" headerClass="text-orange-700" />
                  <IssueSection title="Medium Priority" issues={review.medium} icon={<Info className="w-5 h-5 text-amber-500" />} colorClass="border-amber-200 bg-amber-50" headerClass="text-amber-700" />
                  <IssueSection title="Low Priority" issues={review.low} icon={<CheckCircle2 className="w-5 h-5 text-emerald-500" />} colorClass="border-emerald-200 bg-emerald-50" headerClass="text-emerald-700" />
                </motion.div>
              )}

              {rewrittenCode && (
                <motion.div
                  key="rewrite"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-[#1E1E1E] rounded-2xl shadow-lg overflow-hidden flex flex-col"
                >
                  <div className="px-4 py-3 border-b border-white/10 bg-black/20 flex justify-between items-center">
                    <h2 className="text-sm font-medium text-slate-200">Optimized Code</h2>
                    <button 
                      onClick={() => setRewrittenCode(null)}
                      className="text-xs text-slate-400 hover:text-white transition-colors flex items-center gap-1"
                    >
                      <ArrowLeft className="w-3 h-3" />
                      Back to Review
                    </button>
                  </div>
                  <div className="p-4 overflow-x-auto text-sm">
                    <SyntaxHighlighter
                      language="javascript"
                      style={vscDarkPlus}
                      customStyle={{ margin: 0, padding: 0, background: 'transparent' }}
                    >
                      {rewrittenCode}
                    </SyntaxHighlighter>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>
    </div>
  );
}

function IssueSection({ title, issues, icon, colorClass, headerClass }: { title: string, issues: ReviewIssue[], icon: React.ReactNode, colorClass: string, headerClass: string }) {
  if (!issues || issues.length === 0) return null;

  return (
    <div className={`rounded-2xl border ${colorClass} overflow-hidden`}>
      <div className="px-4 py-3 border-b border-inherit bg-white/50 flex items-center gap-2">
        {icon}
        <h3 className={`font-medium ${headerClass}`}>{title} ({issues.length})</h3>
      </div>
      <div className="divide-y divide-inherit bg-white/30">
        {issues.map((issue, idx) => (
          <div key={idx} className="p-4">
            <div className="flex items-start gap-3">
              <div className="mt-0.5 bg-white px-2 py-1 rounded text-xs font-mono text-slate-500 border border-slate-200 shrink-0">
                {issue.line}
              </div>
              <div className="space-y-1.5">
                <p className="text-sm font-medium text-slate-900">{issue.issue}</p>
                <p className="text-sm text-slate-600">{issue.suggestion}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

