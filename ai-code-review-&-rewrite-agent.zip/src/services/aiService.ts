import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface ReviewIssue {
  line: string;
  issue: string;
  suggestion: string;
}

export interface ReviewResponse {
  summary: string;
  critical: ReviewIssue[];
  high: ReviewIssue[];
  medium: ReviewIssue[];
  low: ReviewIssue[];
}

export async function reviewCode(code: string, focusAreas: string[]): Promise<ReviewResponse> {
  const prompt = `You are an expert AI code reviewer and optimization engine with 15+ years of experience. Analyze the following code.
Focus areas: ${focusAreas.length > 0 ? focusAreas.join(", ") : "General code quality, bugs, performance optimization, and security"}.

Provide a structured review categorizing issues into Critical, High, Medium, and Low severity. Focus heavily on optimization and performance improvements.
Include a brief summary of the overall code quality and optimization potential.

Code to review:
\`\`\`
${code}
\`\`\`
`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING, description: "A brief summary of the overall code quality and optimization opportunities." },
          critical: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                line: { type: Type.STRING, description: "Line number or code snippet." },
                issue: { type: Type.STRING, description: "Description of the issue or bottleneck." },
                suggestion: { type: Type.STRING, description: "Suggested fix or optimization." }
              },
              required: ["line", "issue", "suggestion"]
            }
          },
          high: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                line: { type: Type.STRING, description: "Line number or code snippet." },
                issue: { type: Type.STRING, description: "Description of the issue or bottleneck." },
                suggestion: { type: Type.STRING, description: "Suggested fix or optimization." }
              },
              required: ["line", "issue", "suggestion"]
            }
          },
          medium: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                line: { type: Type.STRING, description: "Line number or code snippet." },
                issue: { type: Type.STRING, description: "Description of the issue or bottleneck." },
                suggestion: { type: Type.STRING, description: "Suggested fix or optimization." }
              },
              required: ["line", "issue", "suggestion"]
            }
          },
          low: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                line: { type: Type.STRING, description: "Line number or code snippet." },
                issue: { type: Type.STRING, description: "Description of the issue or bottleneck." },
                suggestion: { type: Type.STRING, description: "Suggested fix or optimization." }
              },
              required: ["line", "issue", "suggestion"]
            }
          }
        },
        required: ["summary", "critical", "high", "medium", "low"]
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("No response from AI");
  }

  return JSON.parse(text) as ReviewResponse;
}

export async function rewriteCode(code: string, review: ReviewResponse): Promise<string> {
  const prompt = `You are an expert AI code optimizer. Rewrite the following code to address the identified issues and optimize its performance, readability, and security.
Return ONLY the rewritten code. Do not include markdown formatting like \`\`\`python or explanations.

Original Code:
${code}

Identified Issues & Optimization Opportunities:
${JSON.stringify(review, null, 2)}
`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
  });

  const text = response.text;
  if (!text) {
    throw new Error("No response from AI");
  }

  // Strip markdown code blocks if the model accidentally includes them
  return text.replace(/^```[\w]*\n/, "").replace(/\n```$/, "").trim();
}
